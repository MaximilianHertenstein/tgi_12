package gg.jte.generated.ondemand;
import org.example.UIState;
@SuppressWarnings("unchecked")
public final class JtemainPageGenerated {
	public static final String JTE_NAME = "mainPage.jte";
	public static final int[] JTE_LINE_INFO = {0,0,3,3,3,3,19,19,19,23,23,23,3,3,3,3};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, UIState uiState) {
		jteOutput.writeContent("\n\n<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n   <link rel=\"stylesheet\" href=\"/webjars/todomvc-app-css/2.4.1/index.css\" type=\"text/css\">\n    <script src=\"/webjars/htmx.org/2.0.6/dist/htmx.min.js\"></script>\n    <title>ToDo-App</title>\n\n</head>\n\n<body>\n    <section class=\"todoapp\" id=\"todoapp\">\n    ");
		gg.jte.generated.ondemand.JteappGenerated.render(jteOutput, jteHtmlInterceptor, uiState);
		jteOutput.writeContent("\n        </section>\n    </body>\n</html>\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		UIState uiState = (UIState)params.get("uiState");
		render(jteOutput, jteHtmlInterceptor, uiState);
	}
}
