package gg.jte.generated.ondemand;
import org.example.ToDo;
@SuppressWarnings("unchecked")
public final class JtetoDoGenerated {
	public static final String JTE_NAME = "toDo.jte";
	public static final int[] JTE_LINE_INFO = {0,0,2,2,2,2,4,4,4,4,4,5,5,5,5,5,5,5,5,5,10,10,10,10,10,11,11,11,11,15,15,15,15,16,16,16,16,17,17,17,20,20,20,20,24,24,24,2,2,2,2};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, ToDo toDo) {
		jteOutput.writeContent("\n<li id=\"todo");
		jteOutput.setContext("li", "id");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("li", null);
		jteOutput.writeContent("\"\n   ");
		var __jte_html_attribute_0 = org.example.Utils.statusToCompleted(toDo.completed());
		if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
			jteOutput.writeContent(" class=\"");
			jteOutput.setContext("li", "class");
			jteOutput.writeUserContent(__jte_html_attribute_0);
			jteOutput.setContext("li", null);
			jteOutput.writeContent("\"");
		}
		jteOutput.writeContent(">\n\n\n    <input class=\"toggle\"\n           type=\"checkbox\"\n          ");
		var __jte_html_attribute_1 = toDo.completed();
		if (__jte_html_attribute_1) {
		jteOutput.writeContent(" checked");
		}
		jteOutput.writeContent("\n           hx-post=\"todos/");
		jteOutput.setContext("input", "hx-post");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("input", null);
		jteOutput.writeContent("/toggleStatus\"\n           hx-target=\"#todoapp\"\n          />\n\n    <label hx-get=\"/todos/");
		jteOutput.setContext("label", "hx-get");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("label", null);
		jteOutput.writeContent("/edit\"\n           hx-target=\"#todo");
		jteOutput.setContext("label", "hx-target");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("label", null);
		jteOutput.writeContent("\"\n           hx-swap=\"outerHTML\"> ");
		jteOutput.setContext("label", null);
		jteOutput.writeUserContent(toDo.text());
		jteOutput.writeContent("\n    </label>\n    <button class=\"destroy\"\n            hx-post=\"todos/");
		jteOutput.setContext("button", "hx-post");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("button", null);
		jteOutput.writeContent("/delete\"\n            hx-target=\"#todoapp\"\n            >\n    </button>\n</li>");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		ToDo toDo = (ToDo)params.get("toDo");
		render(jteOutput, jteHtmlInterceptor, toDo);
	}
}
