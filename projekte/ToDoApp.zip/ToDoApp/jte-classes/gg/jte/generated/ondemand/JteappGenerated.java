package gg.jte.generated.ondemand;
import org.example.UIState;
import org.example.Utils;
import java.util.List;
@SuppressWarnings("unchecked")
public final class JteappGenerated {
	public static final String JTE_NAME = "app.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,5,5,5,5,11,11,17,17,17,17,17,30,30,31,31,32,32,37,37,37,42,42,44,44,44,44,46,46,46,46,46,46,46,46,46,47,47,47,50,50,60,60,60,5,5,5,5};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, UIState uiState) {
		jteOutput.writeContent("\n\n\n    <header class=\"header\">\n        <h1>todos</h1>\n        ");
		jteOutput.writeContent("\n        <form>\n            <input\n                   class=\"new-todo\"\n                   placeholder=\"What needs to be done?\"\n                   name=\"text_of_new_todo\"\n                  ");
		var __jte_html_attribute_0 = true;
		if (__jte_html_attribute_0) {
		jteOutput.writeContent(" autofocus");
		}
		jteOutput.writeContent(">\n            <button type=\"submit\"\n                    style=\"display:none;\"\n                    hx-post=\"/todos/new\"\n                    hx-target=\"#todoapp\"\n            >\n                Add\n            </button>\n        </form>\n    </header>\n\n    <main>\n        <ul class=\"todo-list\">\n            ");
		for (var toDo: uiState.selectedToDos()) {
			jteOutput.writeContent("\n                ");
			gg.jte.generated.ondemand.JtetoDoGenerated.render(jteOutput, jteHtmlInterceptor, toDo);
			jteOutput.writeContent("\n            ");
		}
		jteOutput.writeContent("\n        </ul>\n    </main>\n    <footer class=\"footer\">\n        <span class=\"todo-count\">\n            <strong>");
		jteOutput.setContext("strong", null);
		jteOutput.writeUserContent(uiState.displayOfActiveToDos());
		jteOutput.writeContent("</strong>\n        </span>\n\n\n        <ul class=\"filters\">\n            ");
		for (var filter: List.of("All", "Active", "Completed")) {
			jteOutput.writeContent("\n                <li>\n                    <a hx-post=\"/todos/setFilter/");
			jteOutput.setContext("a", "hx-post");
			jteOutput.writeUserContent(filter);
			jteOutput.setContext("a", null);
			jteOutput.writeContent("\"\n                       hx-target=\"#todoapp\"\n                      ");
			var __jte_html_attribute_1 = Utils.computeFilterClass(uiState.currentFilter(), filter);
			if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_1)) {
				jteOutput.writeContent(" class=\"");
				jteOutput.setContext("a", "class");
				jteOutput.writeUserContent(__jte_html_attribute_1);
				jteOutput.setContext("a", null);
				jteOutput.writeContent("\"");
			}
			jteOutput.writeContent(">\n                        ");
			jteOutput.setContext("a", null);
			jteOutput.writeUserContent(filter);
			jteOutput.writeContent("\n                    </a>\n                </li>\n            ");
		}
		jteOutput.writeContent("\n        </ul>\n\n        <button\n                class=\"clear-completed\"\n                hx-post=\"/todos/clearCompletedToDos\"\n                hx-target=\"#todoapp\">\n            Clear completed\n        </button>\n    </footer>\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		UIState uiState = (UIState)params.get("uiState");
		render(jteOutput, jteHtmlInterceptor, uiState);
	}
}
