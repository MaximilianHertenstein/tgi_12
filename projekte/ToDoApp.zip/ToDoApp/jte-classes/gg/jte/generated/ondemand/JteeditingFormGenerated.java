package gg.jte.generated.ondemand;
import org.example.ToDo;
@SuppressWarnings("unchecked")
public final class JteeditingFormGenerated {
	public static final String JTE_NAME = "editingForm.jte";
	public static final int[] JTE_LINE_INFO = {0,0,2,2,2,2,6,6,6,6,6,7,7,7,7,7,8,8,8,8,10,10,10,10,11,11,11,11,11,11,11,11,11,17,17,17,2,2,2,2};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, ToDo toDo) {
		jteOutput.writeContent("\n\n\n<li id=\"todo");
		jteOutput.setContext("li", "id");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("li", null);
		jteOutput.writeContent("\"  class=\"editing\">\n    <input class=\"edit new-todo\"");
		var __jte_html_attribute_0 = true;
		if (__jte_html_attribute_0) {
		jteOutput.writeContent(" autofocus");
		}
		jteOutput.writeContent("\n           hx-post=\"todos/");
		jteOutput.setContext("input", "hx-post");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("input", null);
		jteOutput.writeContent("/edit\"\n           hx-swap=\"outerHTML\"\n           hx-target=\"#todo");
		jteOutput.setContext("input", "hx-target");
		jteOutput.writeUserContent(toDo.id());
		jteOutput.setContext("input", null);
		jteOutput.writeContent("\"\n          ");
		var __jte_html_attribute_1 = toDo.text();
		if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_1)) {
			jteOutput.writeContent(" value=\"");
			jteOutput.setContext("input", "value");
			jteOutput.writeUserContent(__jte_html_attribute_1);
			jteOutput.setContext("input", null);
			jteOutput.writeContent("\"");
		}
		jteOutput.writeContent("\n           name=\"updated_text_of_new_todo\"\n           hx-trigger=\"blur\"\n    >\n</li>\n\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		ToDo toDo = (ToDo)params.get("toDo");
		render(jteOutput, jteHtmlInterceptor, toDo);
	}
}
