package org.example;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ViewTest {

    @Test
    void getIDs() {
        View view = new View();
        List<ToDo> todos = List.of(
                new ToDo(42, "Kaffee trinken", false),
                new ToDo(7, "Rakete bauen", true)
        );
        List<Integer> ids = view.getIDs(todos);
        assertEquals(List.of(42, 7), ids, "Die IDs sollten extrahiert werden, damit wir sie später klauen können.");
    }

    @Test
    void numberToFilter() {
        View view = new View();
        assertEquals("All", view.numberToFilter(1));
        assertEquals("Active", view.numberToFilter(2));
        assertEquals("Completed", view.numberToFilter(3));
    }

    @Test
    void showToDo() {
        View view = new View();
        ToDo notCompleted = new ToDo(1, "Testaufgabe", false);
        ToDo completed = new ToDo(2, "Erledigte Aufgabe", true);

        String expectedNotCompleted = "❌ Testaufgabe\t\t\t\t ID: 1";
        String expectedCompleted = "✓ Erledigte Aufgabe\t\t\t\t ID: 2";

        assertEquals(expectedNotCompleted, view.showToDo(notCompleted));
        assertEquals(expectedCompleted, view.showToDo(completed));
    }

    @Test
    void numbersFromOneTo() {
        assertEquals(List.of(1, 2, 3), new View().numbersFromOneTo(3));
        assertEquals(List.of(1, 2, 3, 4 , 5), new View().numbersFromOneTo(5));
    }
}