package org.example;



class Main {
      void main() {
        var controller = new TerminalController();
        controller.runApp();

    }
}














