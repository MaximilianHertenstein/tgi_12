// src/test/java/org/example/InvertedEntryTest.java
package org.example;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InvertedEntryTest {

//    @Test
//    void constructorAndGetters() {
//        InvertedEntry entry = new InvertedEntry(3, List.of("FCH", "BMG"));
//        assertEquals(3, entry.key());
//        assertEquals(List.of("FCH", "BMG"), entry.value());
//    }

}
